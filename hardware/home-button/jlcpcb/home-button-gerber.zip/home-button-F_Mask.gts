%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-09-16T09:25:06+09:00*%
%TF.ProjectId,home-button,686f6d65-2d62-4757-9474-6f6e2e6b6963,1*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-09-16 09:25:06*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.200000X0.275000X-0.200000X0.275000X0.200000X-0.275000X0.200000X-0.275000X-0.200000X0*%
%ADD11R,1.000000X0.750000*%
%ADD12R,1.700000X1.700000*%
%ADD13C,1.700000*%
G04 APERTURE END LIST*
D10*
%TO.C,R1*%
X97800000Y-94325000D03*
X97800000Y-92675000D03*
%TD*%
D11*
%TO.C,SW1*%
X99540000Y-91125000D03*
X105540000Y-91125000D03*
X99540000Y-94875000D03*
X105540000Y-94875000D03*
%TD*%
D12*
%TO.C,J1*%
X100000000Y-100000000D03*
D13*
X100000000Y-97460000D03*
X102540000Y-100000000D03*
X102540000Y-97460000D03*
X105080000Y-100000000D03*
X105080000Y-97460000D03*
%TD*%
M02*
